import { createFileRoute, Navigate } from "@tanstack/react-router";

export const Route = createFileRoute("/auth/register")({
  component: () => <Navigate to="/create-wallet" />,
});
